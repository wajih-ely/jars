package ma.net.s2m.kafka.starter.producer.autoconfigure;

import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import io.opentracing.Tracer;
import io.opentracing.contrib.kafka.TracingProducerInterceptor;
import io.opentracing.util.GlobalTracer;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.util.Properties;
import java.util.StringTokenizer;

@Configuration
@EnableConfigurationProperties(KafkaProducerAutoConfiguration.KafkaProducerProperties.class)
@Slf4j
public class KafkaProducerAutoConfiguration {

    private Properties properties;

    @Bean(name = "kafkaProducer")
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public Producer<String, Object> producer(KafkaProducerProperties producerProperties) {
        log.info("Initializing kafkaProducer using properties : {}", this.getProperties(producerProperties).toString());

        KafkaProducer<String, Object> kafkaProducer = new KafkaProducer<>(this.getProperties(producerProperties));

        log.info("kafkaProducer successfully initialized {} using properties : {}", kafkaProducer, this.getProperties(producerProperties));

        return kafkaProducer;
    }

    public Properties getProperties(KafkaProducerProperties producerProperties) {
        if (properties == null) {
            log.info("Creating Kafka producer with following configuration -> " + producerProperties.toString());

            properties = new Properties();
            properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, producerProperties.getBootstrapServers());
            properties.put(ProducerConfig.ACKS_CONFIG, producerProperties.getAcks());

            properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
            properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer");

            if (producerProperties.getAdditionalConfig() != null && !producerProperties.getAdditionalConfig().isEmpty()) {
                StringTokenizer tokenizer = new StringTokenizer(producerProperties.getAdditionalConfig(), ", \t\n\r");
                while (tokenizer.hasMoreTokens()) {
                    String record = tokenizer.nextToken();
                    int endIndex = record.indexOf('=');
                    if (endIndex == -1) {
                        throw new RuntimeException("Failed to parse Map from String");
                    }
                    String key = record.substring(0, endIndex);
                    String value = record.substring(endIndex + 1);
                    properties.put(key.trim(), value.trim());
                }
            }

            // Crypt communication
            if (producerProperties.getTrustedStorePassword() != null && !producerProperties.getTrustedStorePassword().isEmpty()
                    && producerProperties.getTrustedStorePath() != null && !producerProperties.getTrustedStorePath().isEmpty()) {
                log.info("Configuring truststore");

                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                properties.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PKCS12");
                properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, producerProperties.getTrustedStorePassword());
                properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, producerProperties.getTrustedStorePath());
            }

            // Authenticate MTLS
            if (producerProperties.getKeystorePassword() != null && !producerProperties.getKeystorePassword().isEmpty()
                    && producerProperties.getKeystorePath() != null && !producerProperties.getKeystorePath().isEmpty()) {
                log.info("Configuring keystore");

                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                properties.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "PKCS12");
                properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, producerProperties.getKeystorePassword());
                properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, producerProperties.getKeystorePath());
            }

            // Authenticate Oauth2
            if ((producerProperties.getOauthAccessToken() != null && !producerProperties.getOauthAccessToken().isEmpty())
                    || (producerProperties.getOauthEndpoint() != null && !producerProperties.getOauthEndpoint().isEmpty()
                    && producerProperties.getOauthClientId() != null && !producerProperties.getOauthClientId().isEmpty()
                    && producerProperties.getOauthRefreshToken() != null && !producerProperties.getOauthRefreshToken().isEmpty())
                    || (producerProperties.getOauthEndpoint() != null && !producerProperties.getOauthEndpoint().isEmpty()
                    && producerProperties.getOauthClientId() != null && !producerProperties.getOauthClientId().isEmpty()
                    && producerProperties.getOauthClientSecret() != null && !producerProperties.getOauthClientSecret().isEmpty())) {
                properties.put(SaslConfigs.SASL_JAAS_CONFIG, "org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required;");
                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL".equals(properties.getProperty(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG)) ? "SASL_SSL" : "SASL_PLAINTEXT");
                properties.put(SaslConfigs.SASL_MECHANISM, "OAUTHBEARER");
                properties.put(SaslConfigs.SASL_LOGIN_CALLBACK_HANDLER_CLASS, "io.strimzi.kafka.oauth.client.JaasClientOauthLoginCallbackHandler");
            }

            // Trace distributer using Jaeger
            if (producerProperties.getJaegerServiceName() != null && !producerProperties.getJaegerServiceName().isEmpty()) {
                Tracer tracer = io.jaegertracing.Configuration.fromEnv().getTracer();
                GlobalTracer.registerIfAbsent(tracer);

                properties.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG, TracingProducerInterceptor.class.getName());
            }

            if (producerProperties.getSchemaRegistryEndpoint() != null && !producerProperties.getSchemaRegistryEndpoint().isEmpty()) {
                properties.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, producerProperties.getSchemaRegistryEndpoint());
            }
        }

        return properties;
    }

    @Data
    @ConfigurationProperties(prefix = "spring.kafka.producer")
    public static class KafkaProducerProperties {

        private String bootstrapServers;

        private String trustedStorePassword;

        private String trustedStorePath;

        private String keystorePassword;

        private String keystorePath;

        private String oauthClientId;

        private String oauthClientSecret;

        private String oauthAccessToken;

        private String oauthRefreshToken;

        private String oauthEndpoint;

        private String acks;

        private String headers;

        private String additionalConfig;

        private String jaegerServiceName;

        private String blockingProducer;

        private int messagesPerTransaction;

        private String schemaRegistryEndpoint;
    }
}
