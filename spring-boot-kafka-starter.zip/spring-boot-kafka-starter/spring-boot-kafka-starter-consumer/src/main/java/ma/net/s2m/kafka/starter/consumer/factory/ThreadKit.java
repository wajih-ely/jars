package ma.net.s2m.kafka.starter.consumer.factory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadKit {

    public static final ExecutorService cachedThreadPool = Executors.newCachedThreadPool(new NamedThreadFactory("consumer", true));
}
