package ma.net.s2m.kafka.starter.consumer.autoconfigure;

import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import io.opentracing.Tracer;
import io.opentracing.contrib.kafka.TracingProducerInterceptor;
import io.opentracing.util.GlobalTracer;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import ma.net.s2m.kafka.starter.consumer.processor.KafkaBeanPostProcessor;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.util.Properties;
import java.util.StringTokenizer;

@Configuration
@EnableConfigurationProperties(KafkaConsumerAutoConfiguration.KafkaConsumerProperties.class)
@Slf4j
public class KafkaConsumerAutoConfiguration {

    private Properties properties;

    @Bean(name = "kafkaConsumer")
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public Consumer<String, Object> consumer(KafkaConsumerProperties consumerProperties) {
        log.info("Initializing kafkaConsumer using properties : {}", this.getProperties(consumerProperties).toString());

        KafkaConsumer<String, Object> kafkaConsumer = new KafkaConsumer<>(this.getProperties(consumerProperties));

        log.info("kafkaConsumer successfully initialized {} using properties : {}", kafkaConsumer, this.getProperties(consumerProperties));

        return kafkaConsumer;
    }

    @Bean
    @ConditionalOnMissingBean
    public KafkaBeanPostProcessor kafkaBeanPostProcessor(KafkaConsumerProperties consumerProperties) {
        log.info("Initializing KafkaBeanPostProcessor using properties : {}", this.getProperties(consumerProperties).toString());

        KafkaBeanPostProcessor kafkaBeanPostProcessor = new KafkaBeanPostProcessor(this.getProperties(consumerProperties), consumerProperties);

        log.info("kafkaBeanPostProcessor successfully initialized {} using properties : {}", kafkaBeanPostProcessor, this.getProperties(consumerProperties).toString());

        return kafkaBeanPostProcessor;
    }

    public Properties getProperties(KafkaConsumerProperties consumerProperties) {
        if (properties == null) {
            log.info("Creating Kafka consumer with following configuration -> " + consumerProperties.toString());

            properties = new Properties();
            properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, consumerProperties.getBootstrapServers());

            if (consumerProperties.getClientRack() != null && !consumerProperties.getClientRack().isEmpty()) {
                properties.put(ConsumerConfig.CLIENT_RACK_CONFIG, consumerProperties.getClientRack());
            }

            properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumerProperties.getAutoOffsetReset());
            properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, consumerProperties.getEnableAutoCommit());
            properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
            properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroDeserializer");

            if (consumerProperties.getAdditionalConfig() != null && !consumerProperties.getAdditionalConfig().isEmpty()) {
                StringTokenizer tok = new StringTokenizer(consumerProperties.getAdditionalConfig(), ", \t\n\r");
                while (tok.hasMoreTokens()) {
                    String record = tok.nextToken();
                    int endIndex = record.indexOf('=');
                    if (endIndex == -1) {
                        throw new RuntimeException("Failed to parse Map from String");
                    }
                    String key = record.substring(0, endIndex);
                    String value = record.substring(endIndex + 1);
                    properties.put(key.trim(), value.trim());
                }
            }

            if (consumerProperties.getTrustedStorePassword() != null && !consumerProperties.getTrustedStorePassword().isEmpty()
                    && consumerProperties.getTrustedStorePath() != null && !consumerProperties.getTrustedStorePath().isEmpty()) {
                log.info("Configuring truststore");
                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                properties.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PKCS12");
                properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, consumerProperties.getTrustedStorePassword());
                properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, consumerProperties.getTrustedStorePath());
            }

            if (consumerProperties.getKeystorePassword() != null && !consumerProperties.getKeystorePassword().isEmpty()
                    && consumerProperties.getKeystorePath() != null && !consumerProperties.getKeystorePath().isEmpty()) {
                log.info("Configuring keystore");
                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
                properties.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, "PKCS12");
                properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, consumerProperties.getKeystorePassword());
                properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, consumerProperties.getKeystorePath());
            }

            if ((consumerProperties.getOauthAccessToken() != null && !consumerProperties.getOauthAccessToken().isEmpty())
                    || (consumerProperties.getOauthTokenEndpointUri() != null && !consumerProperties.getOauthTokenEndpointUri().isEmpty()
                    && consumerProperties.getOauthClientId() != null && !consumerProperties.getOauthClientId().isEmpty()
                    && consumerProperties.getOauthRefreshToken() != null && !consumerProperties.getOauthRefreshToken().isEmpty())
                    || (consumerProperties.getOauthTokenEndpointUri() != null && !consumerProperties.getOauthTokenEndpointUri().isEmpty()
                    && consumerProperties.getOauthClientId() != null && !consumerProperties.getOauthClientId().isEmpty()
                    && consumerProperties.getOauthClientSecret() != null && !consumerProperties.getOauthClientSecret().isEmpty())) {
                properties.put(SaslConfigs.SASL_JAAS_CONFIG, "org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required;");
                properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL".equals(properties.getProperty(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG)) ? "SASL_SSL" : "SASL_PLAINTEXT");
                properties.put(SaslConfigs.SASL_MECHANISM, "OAUTHBEARER");
                properties.put(SaslConfigs.SASL_LOGIN_CALLBACK_HANDLER_CLASS, "io.strimzi.kafka.oauth.client.JaasClientOauthLoginCallbackHandler");
            }

            if (consumerProperties.getJaegerServiceName() != null && !consumerProperties.getJaegerServiceName().isEmpty()) {
                Tracer tracer = io.jaegertracing.Configuration.fromEnv().getTracer();
                GlobalTracer.registerIfAbsent(tracer);

                properties.put(ConsumerConfig.INTERCEPTOR_CLASSES_CONFIG, TracingProducerInterceptor.class.getName());
            }

            if (consumerProperties.getSchemaRegistryEndpoint() != null && !consumerProperties.getSchemaRegistryEndpoint().isEmpty()) {
                properties.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, consumerProperties.getSchemaRegistryEndpoint());
                properties.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);
            }
        }

        return properties;
    }

    @Data
    @ConfigurationProperties(prefix = "spring.kafka.consumer")
    public static class KafkaConsumerProperties {

        private String bootstrapServers;

        private String autoOffsetReset; //"earliest" or //latest

        private String enableAutoCommit;

        private String clientRack;

        private String trustedStorePassword;

        private String trustedStorePath;

        private String keystorePassword;

        private String keystorePath;

        private String oauthClientId;

        private String oauthClientSecret;

        private String oauthAccessToken;

        private String oauthRefreshToken;

        private String oauthTokenEndpointUri;

        private String additionalConfig;

        private String jaegerServiceName;

        private String schemaRegistryEndpoint;

        private long timeout;

        private AutoRestart autoRestart = new AutoRestart();

        @Getter
        @Setter
        public static class AutoRestart {
            private boolean enabled = true;
            private int interval = 20;
        }
    }
}
