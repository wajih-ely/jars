package ma.net.s2m.kafka.starter.consumer.processor;

import lombok.*;
import lombok.extern.slf4j.Slf4j;
import ma.net.s2m.kafka.starter.consumer.annotation.EnableKafka;
import ma.net.s2m.kafka.starter.consumer.annotation.KafkaListener;
import ma.net.s2m.kafka.starter.consumer.autoconfigure.KafkaConsumerAutoConfiguration;
import ma.net.s2m.kafka.starter.consumer.exception.SkipMessageException;
import ma.net.s2m.kafka.starter.consumer.factory.ThreadKit;
import ma.net.s2m.kafka.starter.consumer.utils.StringUtils;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.config.BeanPostProcessor;

import javax.annotation.PostConstruct;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static java.util.Collections.singletonMap;

@Setter
@Slf4j
public class KafkaBeanPostProcessor implements BeanPostProcessor, DisposableBean {

    private Properties properties;

    private Map<String, AtomicBoolean> consumerRunningCache = new ConcurrentHashMap<>();
    private Map<String, AtomicInteger> consumerRestartedCount = new ConcurrentHashMap<>();

    private AtomicInteger POOL_SEQ = new AtomicInteger(1);

    private KafkaConsumerAutoConfiguration.KafkaConsumerProperties.AutoRestart autoRestart;

    private KafkaConsumerAutoConfiguration.KafkaConsumerProperties kafkaConsumerProperties;

    private BlockingQueue<ConsumeMetadata> queue = new LinkedBlockingQueue<>();

    public KafkaBeanPostProcessor(Properties properties, KafkaConsumerAutoConfiguration.KafkaConsumerProperties kafkaConsumerProperties) {
        this.properties = properties;
        this.autoRestart = kafkaConsumerProperties.getAutoRestart();
        this.kafkaConsumerProperties = kafkaConsumerProperties;
    }

    @Override
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        return o;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        val aClass = bean.getClass();
        val enableKafka = aClass.getAnnotation(EnableKafka.class);

        if (enableKafka != null) {
            for (val method : aClass.getMethods()) {
                val consumerAnnotation = method.getAnnotation(KafkaListener.class);

                if (consumerAnnotation != null) {
                    val topic = consumerAnnotation.topic();

                    if (StringUtils.isBlank(topic)) {
                        throw new IllegalArgumentException(String.format("Topic is required by %s.%s @KafkaListener", aClass.getName(), method.getName()));
                    }

                    String group = consumerAnnotation.group();
                    if (StringUtils.isBlank(group)) {
                        log.info("Group is null, using default value in @EnableKafka");

                        if (StringUtils.isBlank(enableKafka.value())) {
                            throw new IllegalArgumentException(String.format("Group is required by %s.%s @KafkaListener", aClass.getName(), method.getName()));
                        } else {
                            group = enableKafka.value();
                        }
                    }

                    val config = (Properties) properties.clone();
                    config.put(ConsumerConfig.GROUP_ID_CONFIG, group);

                    ConsumeMetadata metadata = ConsumeMetadata.builder()
                            .bean(bean)
                            .config(config)
                            .group(group)
                            .topic(topic)
                            .method(method)
                            .build();
                    queue.add(metadata);
                }
            }
        }

        return bean;
    }

    @Override
    public void destroy() {
        this.autoRestart.setEnabled(false);
        for (AtomicBoolean atomicBoolean : consumerRunningCache.values()) {
            atomicBoolean.set(false);
        }
    }

    @PostConstruct
    public void start() {
        ThreadKit.cachedThreadPool.execute(() -> {
            Thread thread = Thread.currentThread();
            thread.setName("queue-consumer-thread " + POOL_SEQ.getAndIncrement());

            while (this.autoRestart.isEnabled()) {
                try {
                    ConsumeMetadata take = queue.take();
                    String key = take.group + ":" + take.topic;
                    startConsumer(take);

                    AtomicInteger atomicInteger = consumerRestartedCount.get(key);
                    if (atomicInteger == null) {
                        consumerRestartedCount.put(key, new AtomicInteger(0));
                        log.info("Starting consumer group {}, topic {}, metadata {} successfully", take.getGroup(), take.getTopic(), take);
                    } else {
                        log.error("The {} restart of the consumer {}-{} succeeded", atomicInteger.get(), key);
                    }
                } catch (InterruptedException e) {
                    log.error(e.getMessage(), e);
                }
            }
        });
    }

    public void startConsumer(ConsumeMetadata metadata) {
        ThreadKit.cachedThreadPool.execute(() -> {
            String group = metadata.group;
            String topic = metadata.topic;
            Method method = metadata.method;
            Object bean = metadata.bean;

            val consumer = new KafkaConsumer<String, Object>(metadata.config);
            consumer.subscribe(Collections.singletonList(topic));

            val key = group + topic;
            consumerRunningCache.put(key, new AtomicBoolean(true));
            Thread.currentThread().setName(group + "-" + topic + "-" + POOL_SEQ.getAndIncrement());

            boolean isException = false;
            while (consumerRunningCache.get(key).get()) {
                ConsumerRecords<String, Object> consumerRecords = consumer.poll(Duration.ofSeconds(kafkaConsumerProperties.getTimeout()));

                isException = false;
                try {
                    handleRecord(topic, method, bean, consumer, consumerRecords);
                } catch (Throwable ex) {
                    isException = true;
                    handleException(metadata, group, topic, consumer, key, ex);
                }
            }

            if (!isException) {
                consumer.close();
            }
        });
    }

    private void handleRecord(String topic, Method method, Object bean, KafkaConsumer<String, Object> consumer, ConsumerRecords<String, Object> consumerRecords) throws Throwable {
        for (ConsumerRecord<String, Object> consumerRecord : consumerRecords) {
            if (topic.equals(consumerRecord.topic())) {
                final Object value = consumerRecord.value();
                if (value != null) {
                    try {
                        method.invoke(bean, consumerRecord);
                    } catch (InvocationTargetException ex) {
                        if (ex.getCause() instanceof SkipMessageException) {
                            log.warn("Skip message " + ex.getCause().getMessage(), ex.getCause());
                        } else {
                            throw ex.getCause() != null ? ex.getCause() : ex;
                        }
                    }
                }
            }

            consumer.commitSync(singletonMap(
                    new TopicPartition(consumerRecord.topic(), consumerRecord.partition()),
                    new OffsetAndMetadata(consumerRecord.offset() + 1)));
        }
    }

    private void handleException(ConsumeMetadata metadata, String group, String topic, KafkaConsumer<String, Object> consumer, String key, Throwable e) {
        AtomicInteger atomicInteger = consumerRestartedCount.get(key);

        if (atomicInteger == null) {
            consumerRestartedCount.put(key, atomicInteger = new AtomicInteger(0));
        }

        final String message = "Consumer failure occured " + atomicInteger.getAndIncrement() + " failure";

        log.error(message, e);
        consumerRunningCache.get(key).set(false);

        try {
            consumer.close();
        } catch (Exception e1) {
            log.error("Failed to close consumer ", e1);
        }

        try {
            log.info("Enter sleep {} s", this.autoRestart.getInterval());
            TimeUnit.SECONDS.sleep(this.autoRestart.getInterval());
        } catch (InterruptedException anotherException) {
            log.error(e.getMessage(), e);
        }

        if (this.autoRestart.isEnabled()) {
            queue.add(metadata);
            log.info("Put back into the queue" + metadata);
        } else {
            log.warn("AutoRestart is disabled, consumer close {},{}", topic, group);
        }
    }

    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Setter
    @Getter
    @ToString
    public static class ConsumeMetadata {
        private Method method;
        private Object bean;
        private String group;
        private String topic;
        private Properties config;
    }
}
