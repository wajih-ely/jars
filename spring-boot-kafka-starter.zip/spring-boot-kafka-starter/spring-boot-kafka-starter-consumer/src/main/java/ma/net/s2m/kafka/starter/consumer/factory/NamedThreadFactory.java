package ma.net.s2m.kafka.starter.consumer.factory;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class NamedThreadFactory implements ThreadFactory {

    private static final AtomicInteger POOL_SEQ = new AtomicInteger(1);

    private final AtomicInteger threadNumber = new AtomicInteger(1);

    private final String prefix;

    private final boolean daemon;

    private final ThreadGroup threadGroup;

    public NamedThreadFactory() {
        this("pool-" + POOL_SEQ.getAndIncrement(), false);
    }

    public NamedThreadFactory(String prefix) {
        this(prefix, false);
    }

    public NamedThreadFactory(String prefix, boolean daemon) {
        this.prefix = prefix + "-thread-";
        this.daemon = daemon;

        SecurityManager securityManager = System.getSecurityManager();
        this.threadGroup = (securityManager == null) ? Thread.currentThread().getThreadGroup() : securityManager.getThreadGroup();
    }

    public Thread newThread(Runnable runnable) {
        String name = this.prefix + this.threadNumber.getAndIncrement();
        Thread ret = new Thread(this.threadGroup, runnable, name, 0);
        ret.setDaemon(this.daemon);
        return ret;
    }

    public ThreadGroup getThreadGroup() {
        return this.threadGroup;
    }
}