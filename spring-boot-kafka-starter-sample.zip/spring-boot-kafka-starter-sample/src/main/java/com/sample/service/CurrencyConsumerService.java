package com.sample.service;

import lombok.extern.slf4j.Slf4j;
import ma.net.s2m.kafka.starter.consumer.annotation.EnableKafka;
import ma.net.s2m.kafka.starter.consumer.annotation.KafkaListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.sample.dto.Currency;
import org.springframework.stereotype.Service;

@EnableKafka("currency-consumer")
@Service
@Slf4j
public class CurrencyConsumerService {

    @KafkaListener(topic = "currency-topic")
    public void onCurrencyConsumed(ConsumerRecord<String, Object> consumerRecord) {
        Currency currency = (Currency) consumerRecord.value();
        log.info("\t Currency consumer: " + currency.getName() + ", symbol: " + currency.getSymbol());
    }
}
