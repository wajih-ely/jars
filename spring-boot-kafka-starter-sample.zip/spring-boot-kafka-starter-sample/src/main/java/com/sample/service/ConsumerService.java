package com.sample.service;

import lombok.extern.slf4j.Slf4j;
import ma.net.s2m.kafka.starter.consumer.annotation.EnableKafka;
import ma.net.s2m.kafka.starter.consumer.annotation.KafkaListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.sample.dto.User;
import org.springframework.stereotype.Service;

@EnableKafka("users-consumer")
@Service
@Slf4j
public class ConsumerService {

    @KafkaListener(topic = "users-topic")
    public void onUserConsumed(ConsumerRecord<String, Object> consumerRecord) {
        User person = (User) consumerRecord.value();
        log.info("\t User consumer: " + person.getName() + ", age: " + person.getAge());
    }
}
