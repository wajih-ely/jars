package com.sample.service;

import lombok.extern.slf4j.Slf4j;
import ma.net.s2m.kafka.starter.consumer.annotation.EnableKafka;
import ma.net.s2m.kafka.starter.consumer.annotation.KafkaListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.sample.dto.User;
import org.springframework.stereotype.Service;

@EnableKafka
@Service
@Slf4j
public class AnotherConsumerService {

    @KafkaListener(topic = "users-topic", group = "fourth-users-consumer")
    public void anotherOnUserConsumed(ConsumerRecord<String, Object> consumerRecord) {
        User person = (User) consumerRecord.value();
        log.info("\t Another user consumer: " + person.getName() + ", age: " + person.getAge());
    }
}
