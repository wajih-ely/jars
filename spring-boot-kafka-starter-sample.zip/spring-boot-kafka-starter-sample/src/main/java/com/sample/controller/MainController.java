package com.sample.controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.sample.dto.Currency;
import org.sample.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/api")
@Slf4j
public class MainController {

    @Autowired
    @Qualifier("kafkaProducer")
    Producer<String, Object> producer;

    @GetMapping("/produceUser/{name}/{age}")
    public String produceUser(@PathVariable String name, @PathVariable Integer age) {
        User user = new User(name, age);
        producer.send(new ProducerRecord<>(
                "users-topic",
                null,
                new Date().getTime(),
                user.getName(),
                user,
                null
        ));

        return "Produced user";
    }

    @GetMapping("/produceCurrency/{name}/{symbol}")
    public String produceCurrency(@PathVariable String name, @PathVariable String symbol) {
        Currency currency = new Currency(name, symbol);
        producer.send(new ProducerRecord<>(
                "currency-topic",
                null,
                new Date().getTime(),
                currency.getName(),
                currency,
                null
        ));

        return "Produced currency";
    }
}
